import sqlite3
con = sqlite3.connect('project.db')


con.execute("create table addb(bookname text primary key,genre text,quantity int,author text,publication text,price int)")
con.execute("create table sale(bookname text,quantity int,price int,foreign key(bookname) references addb(bookname),foreign key(price) references addb(price))")
#con.execute("drop table addb")
#con.execute("drop table sale")

con.commit()
con.close()
