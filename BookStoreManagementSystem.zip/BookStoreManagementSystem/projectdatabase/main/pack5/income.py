import sqlite3
con = sqlite3.connect('project.db')
c = con.cursor()


def income():
    c.execute("select sum(quantity*price) from sale")
    for x in c:
        print(x)


con.commit()
