import main as mp
from main.pack1 import add as a
from main.pack2 import sale as b
from main.pack3 import display as c
from main.pack4 import sellhist as d
from main.pack5 import income as e
print(mp.main)


while True:
    print("""1.Add books
2.Sell books
3.Display books
4.History
5.Income 
6.Exit""")
    print("Choose any option from above menu:")
    ch = int(input())
    if ch == 1:
        a.add()
    elif ch == 2:
        b.sale()
    elif ch == 3:
        c.display()
    elif ch == 4:
        d.history()
    elif ch == 5:
        e.income()
    else:
        break
