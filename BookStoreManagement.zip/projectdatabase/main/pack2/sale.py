import sqlite3
con = sqlite3.connect('project.db')
c = con.cursor()


def sale():
    title = str(input("Enter book name:"))
    quantity = int(input("Enter quantity:"))
    price = int(input("Enter price:"))
    c.execute("select quantity from addb where bookname='" + title + "'")
    log = c.fetchone()
    if log is not None:
        c.execute("insert into sale values('" + title + "','" + str(quantity) + "','" + str(price) + "')")
        c.execute("update addb set quantity=quantity-'" + str(quantity) + "' where bookname='" + title + "'")
        con.commit()
        print("""++++++++++++++++++++++++BOOK HAS BEEN SOLD++++++++++++++++++++++++""")
    else:
        print(title, "Books not available")


con.commit()
