main = "WELCOME TO BOOKSTORE MANAGAMENT"


def mainpackdemo():
    return
