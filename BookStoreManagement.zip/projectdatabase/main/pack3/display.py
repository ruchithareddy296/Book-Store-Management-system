import sqlite3
con = sqlite3.connect('project.db')
c = con.cursor()


def display():
    print("AVAILABLE BOOKS IN THE BOOKSTORE")
    s = c.execute("select * from addb")
    for v in s:
        print(v)


con.commit()
