import sqlite3
con = sqlite3.connect('project.db')
c = con.cursor()


def add():
    print("All information Promted is mandatory to be filled ")
    title = input("Enter Book Name:")
    genre = input("Enter Genre:")
    quantity = int(input("Enter Quantity:"))
    author = input("Enter Author's Name:")
    publication = input("Enter Publication House:")
    price = int(input("Enter price of Book:"))
    con = sqlite3.connect('project.db')
    c = con.cursor()
    s = c.execute("select * from addb")
    flag = 0
    for v in s:
        if title in v:
            c.execute("update addb set quantity=quantity+'" + str(quantity) + "' where bookname='" + title + "'")
            con.commit()
            print("""++++++++++++++++++++++++SUCCESSFULLY UPDATED++++++++++++++++++++++++""")
            flag = 1

    if flag == 0:
        c.execute(
            "insert into addb(bookname,genre,quantity,author,publication,price) values('" + title + "','" + genre + "','" + str(quantity) + "','" + author + "','" + publication + "','" + str(price) + "')")
        con.commit()
        print("""++++++++++++++++++++++++SUCCESSFULLY ADDED++++++++++++++++++++++++""")


con.commit()
