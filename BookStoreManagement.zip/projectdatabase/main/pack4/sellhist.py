import sqlite3
con = sqlite3.connect('project.db')
c = con.cursor()


def history():
    while True:
        print("1:Sell history details")
        print("2:Reset Sell history")
        print("3:Exit")
        ty = int(input("Enter your choice:"))
        if ty == 1:
            c.execute("select * from sale")
            for u in c:
                print(u)
        elif ty == 2:
            bb = input("1.Delete:2.Pass")
            if bb == 1:
                c.execute("delete from sale")
                con.commit()
            elif bb == 2:
                pass
        else:
            break


con.commit()
